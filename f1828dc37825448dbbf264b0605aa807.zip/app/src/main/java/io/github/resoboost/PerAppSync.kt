package io.github.resoboost

import android.os.Build
import java.util.Locale

/**
 * 按应用降渲染分辨率：走系统 Game Mode 的 downscale 介入，只影响目标应用自己的后台缓冲。
 *
 * 与全局 `wm size` 的区别：不动整块屏幕，`wm size` 的读数不会变（这是正常的，别拿它验证），
 * 效果是目标应用按更小的尺寸渲染再放大显示。配置写在系统侧，目标应用下次拉起时生效。
 *
 * 各版本接口（不同 ROM 支持情况不一致，所以按顺序尝试，取第一个不报错的）：
 * - Android 12：cmd game downscale <factor> <pkg>
 * - Android 13：device_config put game_overlay <pkg> mode=2,downscaleFactor=<f> + cmd game mode 2 <pkg>
 * - Android 14+：cmd game set --mode 2 --downscale <f> <pkg>
 *
 * 限制：Android 13 起系统只对声明了 android:appCategory="game" 的应用生效。
 */
object PerAppSync {

    @Volatile
    var lastError: String? = null
        private set

    /** 最近一次写入的完整命令与返回，供诊断展示 */
    @Volatile
    var lastReport: String = ""
        private set

    fun supported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    fun needsGameCategory(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    /** 给单个应用写入降分辨率配置 */
    fun apply(pkg: String, rule: Rule): Boolean {
        val factor = factorOf(rule)
        if (factor == null) {
            lastError = "读不到物理分辨率，请改用百分比"
            return false
        }

        val report = StringBuilder()
        var lastFailure = "系统拒绝执行"

        for (strategy in strategies(pkg, factor)) {
            report.append("· ").append(strategy.first).append('\n')
            var failed = false
            for (cmd in strategy.second) {
                val out = shell(cmd)
                report.append("  $ ").append(cmd).append('\n')
                report.append(indent(out)).append('\n')
                if (out == null) {
                    failed = true
                    lastFailure = "命令通道不可用（Shizuku 未就绪）"
                } else if (isError(out)) {
                    failed = true
                    lastFailure = firstLine(out)
                }
            }
            if (!failed) {
                val verdict = verify(pkg)
                val state = stateOf(pkg)
                report.append("判定：").append(verdict).append('\n')
                report.append(indent(state)).append('\n')
                lastReport = report.toString()
                lastError = when (verdict) {
                    Verdict.NOT_GAME ->
                        "系统没把这个应用当作游戏（Android 13 起只对游戏生效）"
                    Verdict.NOT_APPLIED ->
                        "配置写入成功，但系统当前仍是标准模式：先把目标应用彻底杀掉再进，仍无效就是该游戏自己接管了游戏模式"
                    else -> null
                }
                return true
            }
        }

        lastReport = report.toString()
        lastError = lastFailure
        return false
    }

    /** 清除单个应用的降分辨率配置（两条路都清一遍，幂等） */
    fun reset(pkg: String): Boolean {
        val cmds = when {
            Build.VERSION.SDK_INT >= 34 -> listOf(
                "cmd game reset $pkg",
                "cmd game mode standard $pkg",
                "device_config delete game_overlay $pkg"
            )
            Build.VERSION.SDK_INT >= 33 -> listOf(
                "cmd game mode 1 $pkg",
                "cmd game reset $pkg",
                "device_config delete game_overlay $pkg"
            )
            else -> listOf(
                "cmd game downscale disable $pkg"
            )
        }
        val report = StringBuilder()
        var failed = false
        for (cmd in cmds) {
            val out = shell(cmd)
            report.append("  $ ").append(cmd).append('\n')
            report.append(indent(out)).append('\n')
            if (out == null) failed = true
        }
        lastReport = report.toString()
        // 清除阶段的报错多半是"本来就没有配置"，不作为失败
        lastError = if (failed) "命令通道不可用（Shizuku 未就绪）" else null
        return !failed
    }

    private enum class Verdict { APPLIED, NOT_GAME, NOT_APPLIED, UNKNOWN }

    /** 读 cmd game list-modes 判断当前是否已切到自定义/性能/省电模式 */
    private fun verify(pkg: String): Verdict {
        val out = shell("cmd game list-modes $pkg") ?: return Verdict.UNKNOWN
        val lower = out.lowercase()
        return when {
            lower.contains("unsupported") || lower.contains("not a game") -> Verdict.NOT_GAME
            lower.contains("current mode: custom") -> Verdict.APPLIED
            lower.contains("current mode: performance") -> Verdict.APPLIED
            lower.contains("current mode: battery") -> Verdict.APPLIED
            lower.contains("current mode: standard") -> Verdict.NOT_APPLIED
            else -> Verdict.UNKNOWN
        }
    }

    /** 读当前系统侧的配置状态，供界面诊断展示 */
    fun stateOf(pkg: String): String {
        val sb = StringBuilder()
        sb.append("Android SDK: ").append(Build.VERSION.SDK_INT).append('\n')
        sb.append("设备: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        for (cmd in listOf(
            "cmd game list-modes $pkg",
            "device_config get game_overlay $pkg",
            "cmd game list-configs",
            "dumpsys game | grep -i $pkg"
        )) {
            sb.append("$ ").append(cmd).append('\n')
            sb.append(indent(shell(cmd))).append('\n')
        }
        return sb.toString()
    }

    private fun strategies(pkg: String, factor: String): List<Pair<String, List<String>>> = when {
        Build.VERSION.SDK_INT >= 34 -> listOf(
            "custom Game Mode（14 官方路径，不带 --mode）" to listOf(
                "cmd game set --downscale $factor $pkg"
            ),
            "custom Game Mode + 性能模式" to listOf(
                "cmd game set --mode 2 --downscale $factor $pkg"
            ),
            "game_overlay 双模式（官方文档写法）" to listOf(
                "device_config put game_overlay $pkg mode=2,downscaleFactor=$factor:mode=3,downscaleFactor=$factor",
                "cmd game mode 2 $pkg"
            ),
            "game_overlay + 性能模式" to listOf(
                "device_config put game_overlay $pkg mode=2,downscaleFactor=$factor",
                "cmd game mode 2 $pkg"
            ),
            "省电模式 downscale" to listOf(
                "cmd game set --mode 3 --downscale $factor $pkg"
            )
        )
        Build.VERSION.SDK_INT >= 33 -> listOf(
            "game_overlay 双模式（官方文档写法）" to listOf(
                "device_config put game_overlay $pkg mode=2,downscaleFactor=$factor:mode=3,downscaleFactor=$factor",
                "cmd game mode 2 $pkg"
            ),
            "game_overlay + performance 模式" to listOf(
                "device_config put game_overlay $pkg mode=2,downscaleFactor=$factor",
                "cmd game mode 2 $pkg"
            ),
            "custom Game Mode" to listOf(
                "cmd game set --mode 2 --downscale $factor $pkg"
            ),
            "省电模式 downscale" to listOf(
                "cmd game set --mode 3 --downscale $factor $pkg"
            )
        )
        else -> listOf(
            "cmd game downscale" to listOf(
                "cmd game downscale $factor $pkg"
            )
        )
    }

    /**
     * 百分比规则直接用 percent/100；自定义宽高按"宽 / 物理宽"折算，
     * 这样两种规则在按应用模式下都能用。
     */
    private fun factorOf(rule: Rule): String? {
        if (rule.width > 0 && rule.height > 0) {
            val width = physicalWidth() ?: return null
            val f = (rule.width.toDouble() / width).coerceIn(0.3, 1.0)
            return String.format(Locale.US, "%.2f", f)
        }
        val percent = rule.percent.coerceIn(30, 100)
        return String.format(Locale.US, "%.2f", percent / 100.0)
    }

    private var cachedWidth: Int? = null

    private fun physicalWidth(): Int? {
        cachedWidth?.let { return it }
        val size = Parser.physicalSize(ShizukuShell.exec("wm size")) ?: return null
        cachedWidth = size.first
        return size.first
    }

    /** 统一带上 stderr，否则命令失败的报错会被吞掉，表现为"静默成功" */
    private fun shell(cmd: String): String? = ShizukuShell.exec("$cmd 2>&1")

    private fun isError(text: String): Boolean {
        if (text.isEmpty()) return false
        val lower = text.lowercase()
        return listOf(
            "error", "unknown option", "unknown command", "exception",
            "not found", "no such", "doesn't exist", "invalid", "unable", "not a game"
        ).any { lower.contains(it) }
    }

    private fun firstLine(text: String): String =
        text.lineSequence().firstOrNull { it.isNotBlank() }?.trim() ?: "命令返回异常"

    private fun indent(text: String?): String {
        if (text.isNullOrBlank()) return "  (无输出)"
        val lines = text.trim().lines()
        val head = lines.take(40).joinToString("\n") { "  $it" }
        return if (lines.size > 40) "$head\n  …（共 ${lines.size} 行）" else head
    }
}
