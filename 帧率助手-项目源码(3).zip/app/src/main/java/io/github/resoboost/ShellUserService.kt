package io.github.resoboost

import kotlin.system.exitProcess

/**
 * 通过 Shizuku UserService 机制运行在 shell（uid 2000）进程中的命令执行服务。
 * 这是 Shizuku 官方推荐的执行 shell 命令方式，wm / dumpsys 均可用 shell 权限执行。
 */
class ShellUserService : IShellService.Stub() {

    override fun exec(cmd: String): String? {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = process.inputStream.bufferedReader().use { it.readText() }
            process.waitFor()
            process.destroy()
            out
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("unused")
    fun destroy() {
        exitProcess(0)
    }
}
