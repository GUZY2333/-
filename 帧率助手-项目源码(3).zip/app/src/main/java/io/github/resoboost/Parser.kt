package io.github.resoboost

/**
 * 纯解析逻辑，与 Android 框架无关，便于 JVM 单元测试。
 */
object Parser {

    private val resumedRegex =
        Regex("""(?:mResumedActivity|topResumedActivity)[^\n]*?\s([A-Za-z0-9_.]+)/""")
    private val focusRegex =
        Regex("""mCurrentFocus[^\n]*?\s([A-Za-z0-9_.]+)/""")
    private val sizeRegex =
        Regex("""(Physical|Override) size:\s*(\d+)x(\d+)""")

    /** 从 dumpsys 输出中解析前台应用包名 */
    fun foregroundPackage(dump: String?): String? {
        if (dump.isNullOrBlank()) return null
        resumedRegex.find(dump)?.groupValues?.get(1)?.let { return it }
        return focusRegex.find(dump)?.groupValues?.get(1)
    }

    /** 从 `wm size` 输出中解析物理分辨率（优先 Physical，缺失时退回 Override） */
    fun physicalSize(wmOutput: String?): Pair<Int, Int>? {
        if (wmOutput.isNullOrBlank()) return null
        val matches = sizeRegex.findAll(wmOutput).toList()
        val m = matches.firstOrNull { it.groupValues[1] == "Physical" }
            ?: matches.firstOrNull()
            ?: return null
        return Pair(m.groupValues[2].toInt(), m.groupValues[3].toInt())
    }

    /** 按百分比缩放分辨率，结果取偶数，避免个别机型对奇数分辨率不兼容 */
    fun scaledSize(base: Pair<Int, Int>, percent: Int): Pair<Int, Int> {
        fun scale(v: Int): Int = ((v * percent / 100) / 2 * 2).coerceAtLeast(2)
        return Pair(scale(base.first), scale(base.second))
    }
}
