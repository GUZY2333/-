package io.github.resoboost

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * 通过 Shizuku UserService（shell 权限进程）执行命令的封装。
 * - 首次调用自动绑定；绑定是异步的，连接建立前 exec 返回 null。
 * - Shizuku 的绑定接口没有失败回调：这里用超时重绑实现自愈，
 *   并把真实错误记录到 lastError 供界面展示。
 * - daemon(false)：App 进程退出时 Shizuku 自动销毁服务。
 */
object ShizukuShell {

    private const val APP_ID = "io.github.resoboost"
    private const val BIND_TIMEOUT_MS = 8000L

    @Volatile
    private var service: IShellService? = null

    @Volatile
    private var bindRequested = false

    @Volatile
    private var bindStartedAt = 0L

    @Volatile
    var lastError: String? = null
        private set

    private val args = Shizuku.UserServiceArgs(
        ComponentName(APP_ID, ShellUserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("shell")
        .debuggable(false)
        .version(2)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IShellService.Stub.asInterface(binder)
            lastError = null
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            bindRequested = false
        }
    }

    fun isReady(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        false
    }

    fun isConnected(): Boolean = service != null

    /** 触发/维持绑定，可由界面定时调用 */
    fun warmup() {
        ensureBound()
    }

    private fun ensureBound() {
        if (service != null || !isReady()) return
        val now = System.currentTimeMillis()
        if (bindRequested && now - bindStartedAt < BIND_TIMEOUT_MS) return
        if (bindRequested) {
            // 超时仍未连接：清理旧连接后重试
            try {
                Shizuku.unbindUserService(args, connection, false)
            } catch (e: Exception) {
                // ignore
            }
            bindRequested = false
        }
        try {
            Shizuku.bindUserService(args, connection)
            bindRequested = true
            bindStartedAt = now
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            bindRequested = false
        }
    }

    fun exec(cmd: String): String? {
        if (!isReady()) {
            lastError = "Shizuku 未运行或未授权"
            return null
        }
        ensureBound()
        val s = service ?: return null
        return try {
            s.exec(cmd)
        } catch (e: Exception) {
            lastError = "命令服务调用失败：${e.message}"
            service = null
            bindRequested = false
            null
        }
    }
}
