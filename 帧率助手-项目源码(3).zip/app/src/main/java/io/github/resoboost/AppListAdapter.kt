package io.github.resoboost

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import io.github.resoboost.databinding.ItemAppBinding

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

class AppListAdapter(private val store: RuleStore) :
    RecyclerView.Adapter<AppListAdapter.VH>() {

    private val all = ArrayList<AppItem>()
    private val shown = ArrayList<AppItem>()
    private val rules = store.load()
    private var query = ""

    private val percents = listOf(90, 85, 80, 75, 70, 60, 50)

    class VH(val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun getItemCount(): Int = shown.size

    fun submit(items: List<AppItem>) {
        all.clear()
        all.addAll(items)
        applyFilter()
    }

    fun filter(q: String) {
        query = q.trim()
        applyFilter()
    }

    private fun applyFilter() {
        shown.clear()
        shown.addAll(all.filter {
            query.isEmpty() ||
                it.label.contains(query, ignoreCase = true) ||
                it.pkg.contains(query, ignoreCase = true)
        })
        notifyDataSetChanged()
    }

    private fun ruleFor(pkg: String): Rule = rules.getOrPut(pkg) { Rule(pkg) }

    private fun describe(rule: Rule): String =
        if (rule.width > 0 && rule.height > 0) "${rule.width}×${rule.height}" else "${rule.percent}%"

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = shown[position]
        val rule = ruleFor(item.pkg)
        val ctx = holder.itemView.context

        holder.binding.icon.setImageDrawable(item.icon)
        holder.binding.label.text = item.label
        holder.binding.pkg.text = item.pkg
        holder.binding.percent.text = describe(rule)

        holder.binding.enabled.setOnCheckedChangeListener(null)
        holder.binding.enabled.isChecked = rule.enabled
        holder.binding.enabled.setOnCheckedChangeListener { _, checked ->
            rule.enabled = checked
            store.save(rules)
        }

        holder.binding.percent.setOnClickListener {
            val entries = percents.map { "$it%" }.toMutableList().apply { add("自定义宽高…") }
            AlertDialog.Builder(ctx)
                .setTitle(item.label)
                .setItems(entries.toTypedArray()) { _, which ->
                    if (which == entries.size - 1) {
                        showCustomDialog(holder, item, rule)
                    } else {
                        rule.percent = percents[which]
                        rule.width = 0
                        rule.height = 0
                        store.save(rules)
                        holder.binding.percent.text = describe(rule)
                    }
                }
                .show()
        }
    }

    private fun showCustomDialog(holder: VH, item: AppItem, rule: Rule) {
        val ctx = holder.itemView.context
        val density = ctx.resources.displayMetrics.density
        fun pad(v: Int) = (v * density).toInt()

        val widthInput = EditText(ctx).apply {
            hint = "宽（像素），如 810"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            if (rule.width > 0) setText(rule.width.toString())
        }
        val heightInput = EditText(ctx).apply {
            hint = "高（像素），如 1800"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            if (rule.height > 0) setText(rule.height.toString())
        }
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad(24), pad(8), pad(24), 0)
            addView(widthInput)
            addView(heightInput)
        }
        AlertDialog.Builder(ctx)
            .setTitle("自定义分辨率 · ${item.label}")
            .setView(layout)
            .setPositiveButton("确定") { _, _ ->
                val w = widthInput.text.toString().toIntOrNull() ?: 0
                val h = heightInput.text.toString().toIntOrNull() ?: 0
                if (w in 200..8000 && h in 200..8000) {
                    rule.width = w
                    rule.height = h
                    store.save(rules)
                    holder.binding.percent.text = describe(rule)
                } else {
                    Toast.makeText(ctx, "请输入 200–8000 之间的宽高", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }
}
