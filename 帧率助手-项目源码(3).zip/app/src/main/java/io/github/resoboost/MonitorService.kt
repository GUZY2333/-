package io.github.resoboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * 前台监测服务：
 * 每秒检测前台应用，命中已启用规则的应用则通过 Shizuku 执行 `wm size` 降分辨率；
 * 离开目标应用 / 熄屏时执行 `wm size reset` 恢复。
 */
class MonitorService : Service() {

    companion object {
        const val ACTION_STOP = "io.github.resoboost.action.STOP"
        private const val CHANNEL_ID = "monitor"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
            private set
    }

    @Volatile
    private var runningFlag = false
    private var worker: Thread? = null
    private var appliedPkg: String? = null
    private var lastNotifText: String = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            CHANNEL_ID, "分辨率自动切换", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        startInForeground("正在启动…")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!runningFlag) {
            runningFlag = true
            running = true
            worker = Thread({ loop() }, "reso-monitor").apply { start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        runningFlag = false
        running = false
        worker?.interrupt()
        // 尽力恢复分辨率，防止停留在低分辨率状态
        try {
            if (appliedPkg != null) {
                ShizukuShell.exec("wm size reset")
                appliedPkg = null
            }
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }

    private fun loop() {
        val store = RuleStore(this)
        val powerManager = getSystemService(PowerManager::class.java)
        var baseSize: Pair<Int, Int>? = null

        while (runningFlag) {
            try {
                if (!ShizukuShell.isReady()) {
                    appliedPkg = null
                    updateNotification("Shizuku 未连接或未授权，已暂停")
                    Thread.sleep(3000)
                    continue
                }

                if (!ShizukuShell.isConnected()) {
                    ShizukuShell.exec("true") // 触发 UserService 绑定
                    val err = ShizukuShell.lastError
                    updateNotification("正在连接 Shizuku 命令服务…" + (err?.let { "（$it）" } ?: ""))
                    Thread.sleep(1000)
                    continue
                }

                val screenOn = powerManager.isInteractive
                val rules = store.load()
                val fg = if (screenOn) detectForeground() else null
                val rule = fg?.let { rules[it] }?.takeIf { it.enabled }

                if (rule != null && fg != null) {
                    if (appliedPkg != fg) {
                        if (baseSize == null) {
                            baseSize = Parser.physicalSize(ShizukuShell.exec("wm size"))
                        }
                        val size = if (rule.width > 0 && rule.height > 0) {
                            Pair(rule.width, rule.height)
                        } else {
                            baseSize?.let { Parser.scaledSize(it, rule.percent) }
                        }
                        if (size != null) {
                            ShizukuShell.exec("wm size ${size.first}x${size.second}")
                            appliedPkg = fg
                            updateNotification("已降分辨率：$fg → ${size.first}x${size.second}")
                        } else {
                            updateNotification("无法读取屏幕分辨率，等待重试")
                        }
                    }
                } else if (appliedPkg != null) {
                    ShizukuShell.exec("wm size reset")
                    appliedPkg = null
                    updateNotification("监测中，分辨率已恢复")
                } else {
                    updateNotification(if (screenOn) "监测中…" else "熄屏中，已暂停监测")
                }
            } catch (e: InterruptedException) {
                break
            } catch (e: Exception) {
                updateNotification("监测异常，自动重试中")
            }
            try {
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun detectForeground(): String? {
        val resumed = ShizukuShell.exec(
            "dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity'"
        )
        Parser.foregroundPackage(resumed)?.let { return it }
        val focus = ShizukuShell.exec("dumpsys window | grep mCurrentFocus")
        return Parser.foregroundPackage(focus)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val contentIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("帧率助手")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)
            .addAction(0, "停止", stopIntent)
            .build()
    }

    private fun startInForeground(text: String) {
        lastNotifText = text
        val type = if (Build.VERSION.SDK_INT >= 34) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(text), type)
    }

    private fun updateNotification(text: String) {
        if (text == lastNotifText) return
        lastNotifText = text
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }
}
