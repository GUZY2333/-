package io.github.resoboost

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * 通过 Shizuku UserService（shell 权限进程）执行命令的封装。
 * 首次调用 exec 时自动绑定服务；绑定是异步的，连接建立前 exec 返回 null，
 * 调用方（监测循环 / 按钮）按失败重试即可。
 * daemon(false)：App 进程退出时 Shizuku 会自动销毁该服务，无需手动解绑。
 */
object ShizukuShell {

    private const val APP_ID = "io.github.resoboost"

    @Volatile
    private var service: IShellService? = null

    @Volatile
    private var bindRequested = false

    private val args = Shizuku.UserServiceArgs(
        ComponentName(APP_ID, ShellUserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("shell")
        .debuggable(false)
        .version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IShellService.Stub.asInterface(binder)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            bindRequested = false
        }
    }

    fun isReady(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        false
    }

    fun isConnected(): Boolean = service != null

    private fun ensureBound() {
        if (service == null && !bindRequested && isReady()) {
            try {
                Shizuku.bindUserService(args, connection)
                bindRequested = true
            } catch (e: Exception) {
                // Shizuku 未运行等情况，下次调用再试
            }
        }
    }

    fun exec(cmd: String): String? {
        if (!isReady()) return null
        ensureBound()
        val s = service ?: return null
        return try {
            s.exec(cmd)
        } catch (e: Exception) {
            service = null
            bindRequested = false
            null
        }
    }
}
