# Shizuku
-keep class rikka.shizuku.** { *; }
-keep class io.github.resoboost.** { *; }
