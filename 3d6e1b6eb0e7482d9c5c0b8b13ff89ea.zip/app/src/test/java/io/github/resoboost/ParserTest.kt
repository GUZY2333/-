package io.github.resoboost

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ParserTest {

    @Test
    fun parseResumedActivity() {
        val dump = "  mResumedActivity: ActivityRecord{1a2b3c u0 com.tencent.tmgp.sgame/.SGameActivity t123}"
        assertEquals("com.tencent.tmgp.sgame", Parser.foregroundPackage(dump))
    }

    @Test
    fun parseTopResumedActivity() {
        val dump = "    topResumedActivity=ActivityRecord{abc123 u0 com.miHoYo.Yuanshen/com.miHoYo.GetMobileInfo.MainActivity t456}"
        assertEquals("com.miHoYo.Yuanshen", Parser.foregroundPackage(dump))
    }

    @Test
    fun parseCurrentFocusFallback() {
        val dump = "  mCurrentFocus=Window{def456 u0 com.example.game/com.example.game.MainActivity}"
        assertEquals("com.example.game", Parser.foregroundPackage(dump))
    }

    @Test
    fun parseFocusedAppFallback() {
        val dump = "  mFocusedApp=AppWindowToken{9a8b7c token=Token{123 ActivityRecord{456 u0 com.example.game/com.example.game.MainActivity t789}}}"
        assertEquals("com.example.game", Parser.foregroundPackage(dump))
    }

    @Test
    fun nullOnEmptyInput() {
        assertNull(Parser.foregroundPackage(null))
        assertNull(Parser.foregroundPackage(""))
        assertNull(Parser.foregroundPackage("no match here"))
    }

    @Test
    fun physicalSizePreferredOverOverride() {
        val out = "Physical size: 1080x2400\nOverride size: 810x1800"
        assertEquals(Pair(1080, 2400), Parser.physicalSize(out))
    }

    @Test
    fun overrideSizeFallback() {
        assertEquals(Pair(720, 1600), Parser.physicalSize("Override size: 720x1600"))
    }

    @Test
    fun nullSizeOnGarbage() {
        assertNull(Parser.physicalSize(null))
        assertNull(Parser.physicalSize("Permission denial"))
    }

    @Test
    fun scale75Percent() {
        assertEquals(Pair(810, 1800), Parser.scaledSize(Pair(1080, 2400), 75))
    }

    @Test
    fun scale70Percent() {
        assertEquals(Pair(756, 1680), Parser.scaledSize(Pair(1080, 2400), 70))
    }

    @Test
    fun scaleRoundsToEven() {
        // 1079*70/100=755 -> 754; 2399*70/100=1679 -> 1678
        assertEquals(Pair(754, 1678), Parser.scaledSize(Pair(1079, 2399), 70))
    }
}
