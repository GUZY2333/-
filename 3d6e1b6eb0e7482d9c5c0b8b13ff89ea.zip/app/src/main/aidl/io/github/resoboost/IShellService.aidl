package io.github.resoboost;

interface IShellService {
    String exec(String cmd);
}
