package io.github.resoboost

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 单个应用的降分辨率规则。
 * width/height > 0 时使用自定义分辨率，否则按 percent 百分比缩放。
 */
data class Rule(
    val pkg: String,
    var enabled: Boolean = false,
    var percent: Int = 75,
    var width: Int = 0,
    var height: Int = 0
)

class RuleStore(context: Context) {

    private val prefs = context.getSharedPreferences("rules", Context.MODE_PRIVATE)

    fun load(): MutableMap<String, Rule> {
        val map = LinkedHashMap<String, Rule>()
        val raw = prefs.getString("rules_json", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val rule = Rule(
                    pkg = o.getString("pkg"),
                    enabled = o.optBoolean("enabled", false),
                    percent = o.optInt("percent", 75),
                    width = o.optInt("width", 0),
                    height = o.optInt("height", 0)
                )
                map[rule.pkg] = rule
            }
        } catch (e: Exception) {
            // 数据损坏时回退为空规则，不影响启动
        }
        return map
    }

    fun save(rules: Map<String, Rule>) {
        val arr = JSONArray()
        for (r in rules.values) {
            arr.put(
                JSONObject()
                    .put("pkg", r.pkg)
                    .put("enabled", r.enabled)
                    .put("percent", r.percent)
                    .put("width", r.width)
                    .put("height", r.height)
            )
        }
        prefs.edit().putString("rules_json", arr.toString()).apply()
    }
}
