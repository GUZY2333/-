package io.github.resoboost

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * 开机兜底：wm size 的修改会跨重启保留。
 * 开机时若 Shizuku 已就绪则恢复默认分辨率，避免手机卡在低分辨率。
 * （Shizuku 通常在开机后才激活，此时兜底可能失败；App 启动时还有第二道兜底。）
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        Thread {
            try {
                if (ShizukuShell.isReady()) {
                    repeat(5) {
                        val r = ShizukuShell.exec("wm size reset")
                        if (r != null) return@Thread
                        try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
                    }
                }
            } catch (e: Exception) {
                // ignore
            } finally {
                pending.finish()
            }
        }.start()
    }
}
