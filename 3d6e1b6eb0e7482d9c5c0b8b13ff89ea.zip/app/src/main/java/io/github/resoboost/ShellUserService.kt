package io.github.resoboost

import kotlin.system.exitProcess
import java.util.concurrent.TimeUnit

/**
 * 通过 Shizuku UserService 机制运行在 shell（uid 2000）进程中的命令执行服务。
 * 这是 Shizuku 官方推荐的执行 shell 命令方式，wm / dumpsys 均可用 shell 权限执行。
 */
class ShellUserService : IShellService.Stub() {

    companion object {
        /** 单条命令的最长等待时间，超时直接强杀，避免调用方被拖死 */
        private const val TIMEOUT_MS = 5000L
    }

    override fun exec(cmd: String): String? {
        return try {
            // redirectErrorStream(true)：stderr 并入 stdout，避免只读 stdout 时 stderr 写满管道卡住
            val process = ProcessBuilder("sh", "-c", cmd)
                .redirectErrorStream(true)
                .start()

            var output: String? = null
            val reader = Thread({
                try {
                    output = process.inputStream.bufferedReader().use { it.readText() }
                } catch (e: Exception) {
                    // 强杀进程时读流会被打断，属正常路径
                }
            }, "user-service-exec")
            reader.start()
            reader.join(TIMEOUT_MS)
            if (reader.isAlive) {
                process.destroyForcibly()
                reader.join(1000)
                return null
            }

            if (!process.waitFor(TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                process.destroyForcibly()
                return null
            }
            process.destroy()
            output
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("unused")
    fun destroy() {
        exitProcess(0)
    }
}
