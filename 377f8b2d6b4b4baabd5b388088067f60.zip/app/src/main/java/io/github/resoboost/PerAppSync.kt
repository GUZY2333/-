package io.github.resoboost

import android.os.Build
import java.util.Locale

/**
 * 按应用降渲染分辨率：走系统 Game Mode 的 downscale 介入，只影响目标应用自己的后台缓冲。
 *
 * 与全局 `wm size` 的区别：不切换整块屏幕，没有闪屏，切走不用恢复，也不会留下跨重启的
 * 全局 resolution override。配置写在系统侧，目标应用下次拉起时生效（正在运行的可能要重启）。
 *
 * 各版本接口：
 * - Android 12：cmd game downscale <factor> <pkg> / cmd game downscale disable <pkg>
 * - Android 13：device_config put game_overlay <pkg> mode=2,downscaleFactor=<f>
 *               + cmd game mode 2 <pkg>
 *   reset：cmd game mode 1 <pkg> + cmd game reset <pkg> + device_config delete game_overlay <pkg>
 * - Android 14+：cmd game set --mode 2 --downscale <f> <pkg>
 *   reset：cmd game reset <pkg> + cmd game mode standard <pkg>
 *
 * 限制：Android 13 起系统只对声明了 android:appCategory="game" 的应用生效（正常游戏都有声明）。
 * 12 则对任何应用都可下发。
 */
object PerAppSync {

    @Volatile
    var lastError: String? = null
        private set

    /** 按应用降分辨率需要 Android 12（API 31）及以上 */
    fun supported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    /** 13 起要求应用被系统认定为游戏 */
    fun needsGameCategory(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    /** 给单个应用写入降分辨率配置 */
    fun apply(pkg: String, rule: Rule): Boolean {
        val factor = factorOf(rule)
        if (factor == null) {
            lastError = "无法读取物理分辨率，请改用百分比"
            return false
        }
        val cmds = when {
            Build.VERSION.SDK_INT >= 34 -> listOf(
                "cmd game set --mode 2 --downscale $factor $pkg"
            )
            Build.VERSION.SDK_INT >= 33 -> listOf(
                "device_config put game_overlay $pkg mode=2,downscaleFactor=$factor",
                "cmd game mode 2 $pkg"
            )
            else -> listOf(
                "cmd game downscale $factor $pkg"
            )
        }
        return run(cmds)
    }

    /** 清除单个应用的降分辨率配置 */
    fun reset(pkg: String): Boolean {
        val cmds = when {
            Build.VERSION.SDK_INT >= 34 -> listOf(
                "cmd game reset $pkg",
                "cmd game mode standard $pkg"
            )
            Build.VERSION.SDK_INT >= 33 -> listOf(
                "cmd game mode 1 $pkg",
                "cmd game reset $pkg",
                "device_config delete game_overlay $pkg"
            )
            else -> listOf(
                "cmd game downscale disable $pkg"
            )
        }
        return run(cmds)
    }

    /**
     * 百分比规则直接用 percent/100；自定义宽高则按"宽 / 物理宽"折算成比例，
     * 这样两种规则在按应用模式下都能用。
     */
    private fun factorOf(rule: Rule): String? {
        if (rule.width > 0 && rule.height > 0) {
            val width = physicalWidth() ?: return null
            val f = (rule.width.toDouble() / width).coerceIn(0.3, 1.0)
            return String.format(Locale.US, "%.2f", f)
        }
        val percent = rule.percent.coerceIn(30, 100)
        return String.format(Locale.US, "%.2f", percent / 100.0)
    }

    private var cachedWidth: Int? = null

    private fun physicalWidth(): Int? {
        cachedWidth?.let { return it }
        val size = Parser.physicalSize(ShizukuShell.exec("wm size")) ?: return null
        cachedWidth = size.first
        return size.first
    }

    private fun run(cmds: List<String>): Boolean {
        val errors = ArrayList<String>()
        for (cmd in cmds) {
            val out = ShizukuShell.exec(cmd)
            if (out == null) {
                errors.add(ShizukuShell.lastError ?: "命令执行失败：${cmd.take(40)}")
                continue
            }
            val text = out.trim()
            if (looksLikeError(text)) {
                errors.add(text.lineSequence().firstOrNull { it.isNotBlank() } ?: "命令返回异常")
            }
        }
        lastError = if (errors.isEmpty()) null else errors.joinToString("；").take(200)
        return errors.isEmpty()
    }

    private fun looksLikeError(text: String): Boolean {
        if (text.isEmpty()) return false
        val lower = text.lowercase()
        return lower.contains("error") || lower.contains("unknown") ||
            lower.contains("exception") || lower.contains("not found") ||
            lower.contains("no such") || lower.contains("doesn't exist")
    }
}
