package io.github.resoboost

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import io.github.resoboost.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    companion object {
        private const val KEY_PER_APP_MODE = "per_app_mode"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AppListAdapter
    private lateinit var store: RuleStore

    private val settings by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    /** true = 按应用降分辨率（系统 Game Mode），false = 全局 wm size 切换 */
    private var perAppMode = false
    private var suppressModeListener = false

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { _, _ ->
            runOnUiThread { refreshStatus() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = RuleStore(this)
        adapter = AppListAdapter(store) { pkg, rule -> onRuleChanged(pkg, rule) }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter
        binding.search.addTextChangedListener { adapter.filter(it?.toString().orEmpty()) }

        Shizuku.addRequestPermissionResultListener(permissionListener)

        binding.btnAuth.setOnClickListener {
            try {
                Shizuku.requestPermission(1001)
            } catch (e: Exception) {
                toast("Shizuku 未在运行，请先打开 Shizuku 并激活")
            }
        }

        binding.btnReset.setOnClickListener {
            if (!ShizukuShell.isReady()) {
                toast("请先启动 Shizuku 并授权")
                return@setOnClickListener
            }
            Thread {
                val r = ShizukuShell.exec("wm size reset")
                runOnUiThread {
                    toast(if (r != null) "已恢复默认分辨率" else "Shizuku 服务未连接，请稍后再试")
                }
            }.start()
        }

        perAppMode = settings.getBoolean(KEY_PER_APP_MODE, false)
        binding.switchMode.isChecked = perAppMode
        binding.switchMode.setOnCheckedChangeListener { _, checked ->
            if (!suppressModeListener) switchMode(checked)
        }
        binding.btnSync.setOnClickListener { syncAllRules() }

        applyModeUi()
        setSwitchChecked(!perAppMode && MonitorService.running)

        loadApps()

        // 兜底：全局模式下 App 打开且服务未运行时，恢复默认分辨率，
        // 防止服务被杀后手机停留在低分辨率。带重试，等待命令通道建立。
        val needReset = !perAppMode
        Thread {
            if (needReset && !MonitorService.running && ShizukuShell.isReady()) {
                repeat(5) {
                    val r = ShizukuShell.exec("wm size reset")
                    if (r != null) return@Thread
                    try { Thread.sleep(1000) } catch (e: InterruptedException) { return@Thread }
                }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        setSwitchChecked(!perAppMode && MonitorService.running)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun setSwitchChecked(checked: Boolean) {
        binding.switchMonitor.setOnCheckedChangeListener(null)
        binding.switchMonitor.isChecked = checked
        binding.switchMonitor.setOnCheckedChangeListener { _, c ->
            if (c) {
                if (perAppMode) {
                    toast("当前是按应用模式，不需要常驻服务")
                    setSwitchChecked(false)
                    return@setOnCheckedChangeListener
                }
                if (!ShizukuShell.isReady()) {
                    toast("请先启动 Shizuku 并授权")
                    setSwitchChecked(false)
                    return@setOnCheckedChangeListener
                }
                requestNotificationPermissionIfNeeded()
                ContextCompat.startForegroundService(
                    this, Intent(this, MonitorService::class.java)
                )
                toast("自动切换已开启")
            } else {
                stopService(Intent(this, MonitorService::class.java))
                toast("自动切换已关闭，分辨率将恢复")
            }
        }
    }

    private fun switchMode(toPerApp: Boolean) {
        if (toPerApp && !PerAppSync.supported()) {
            toast("按应用降分辨率需要 Android 12 及以上，当前为 Android ${Build.VERSION.RELEASE}")
            setModeChecked(false)
            return
        }
        if (!ShizukuShell.isReady()) {
            toast("请先启动 Shizuku 并授权")
            setModeChecked(false)
            return
        }

        perAppMode = toPerApp
        settings.edit().putBoolean(KEY_PER_APP_MODE, toPerApp).apply()
        applyModeUi()

        if (toPerApp) {
            if (MonitorService.running) stopService(Intent(this, MonitorService::class.java))
            setSwitchChecked(false)
            Thread {
                // 先撤掉可能残留的全局 override，再把已勾选的规则写进系统
                ShizukuShell.exec("wm size reset")
                val msg = syncAllRulesInternal()
                runOnUiThread { toast(msg) }
            }.start()
        } else {
            Thread {
                val msg = resetAllRulesInternal()
                runOnUiThread { toast(msg) }
            }.start()
        }
    }

    private fun setModeChecked(checked: Boolean) {
        if (binding.switchMode.isChecked == checked) return
        suppressModeListener = true
        binding.switchMode.isChecked = checked
        suppressModeListener = false
    }

    private fun applyModeUi() {
        binding.switchMonitor.isEnabled = !perAppMode
        binding.btnSync.visibility = if (perAppMode) View.VISIBLE else View.GONE
        binding.modeHint.text = getString(
            if (perAppMode) R.string.hint_mode_per_app else R.string.hint_mode_global
        )
    }

    private fun syncAllRules() {
        if (!ShizukuShell.isReady()) {
            toast("请先启动 Shizuku 并授权")
            return
        }
        Thread {
            val msg = syncAllRulesInternal()
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun syncAllRulesInternal(): String {
        val enabled = store.load().values.filter { it.enabled }
        if (enabled.isEmpty()) return "还没有勾选任何应用"
        var ok = 0
        for (r in enabled) if (PerAppSync.apply(r.pkg, r)) ok++
        val failed = enabled.size - ok
        return if (failed == 0) {
            "已写入 $ok 个应用的降分辨率设置"
        } else {
            "成功 $ok 个，失败 $failed 个（${PerAppSync.lastError.orEmpty()}）"
        }
    }

    private fun resetAllRulesInternal(): String {
        val rules = store.load().values
        if (rules.isEmpty()) return "已切回全局模式"
        var ok = 0
        for (r in rules) if (PerAppSync.reset(r.pkg)) ok++
        val failed = rules.size - ok
        return if (failed == 0) {
            "已切回全局模式，清除了 ${ok} 个应用的按应用设置"
        } else {
            "已切回全局模式，${failed} 个应用的设置未能清除（${PerAppSync.lastError.orEmpty()}）"
        }
    }

    /** 列表里勾选/改档位后，按应用模式下立刻下发到系统 */
    private fun onRuleChanged(pkg: String, rule: Rule) {
        if (!perAppMode) return
        if (!ShizukuShell.isReady()) {
            toast("请先启动 Shizuku 并授权")
            return
        }
        Thread {
            val enable = rule.enabled
            val ok = if (enable) PerAppSync.apply(pkg, rule) else PerAppSync.reset(pkg)
            val name = pkg.substringAfterLast('.')
            val action = if (enable) "设置" else "清除"
            val err = PerAppSync.lastError?.let { "（$it）" }.orEmpty()
            val hint = if (!ok && enable && PerAppSync.needsGameCategory()) {
                "；Android 13 起只对声明为游戏的应用生效"
            } else {
                ""
            }
            val msg = if (ok) "已${action} ${name} 的按应用降分辨率" else "${action}失败：$name$err$hint"
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun refreshStatus() {
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }
        when {
            !binderAlive -> {
                binding.shizukuStatus.text =
                    "Shizuku 未运行：请先安装 Shizuku，并通过无线调试或电脑激活"
                binding.btnAuth.isEnabled = false
            }
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                binding.shizukuStatus.text = "Shizuku 运行中，尚未授权本应用"
                binding.btnAuth.isEnabled = true
            }
            else -> {
                binding.shizukuStatus.text = "Shizuku 已就绪"
                binding.btnAuth.isEnabled = false
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1002)
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val items = pm.getInstalledApplications(0)
                .filter {
                    it.packageName != packageName &&
                        pm.getLaunchIntentForPackage(it.packageName) != null
                }
                .map { AppItem(it.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .sortedBy { it.label }
            runOnUiThread { adapter.submit(items) }
        }.start()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
