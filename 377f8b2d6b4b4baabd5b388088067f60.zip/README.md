# 帧率助手（ResoBoost）

免 Root，通过 **Shizuku** 实现"指定应用自动降分辨率提帧率"的安卓小工具，配套 **GitHub Actions 云端编译**，本地无需安装任何开发环境。

## 工作原理

本应用有两种生效方式，可在界面上一键切换：

- **全局切换（默认，兼容所有版本）**：`wm size` 改的是整块屏幕的分辨率，系统没有按应用改分辨率的老接口，所以靠前台监测来临时降、切走再恢复：

1. 前台服务每秒通过 Shizuku 检测当前前台应用包名；
2. 命中你勾选的目标应用 → 执行 `wm size 宽x高` 降分辨率（减轻 GPU 渲染压力，提升帧率）；
3. 切走目标应用或熄屏 → 执行 `wm size reset` 自动恢复；
4. 多重兜底：服务停止时恢复、开机尝试恢复、App 打开时若服务未运行也自动恢复，防止手机卡在低分辨率。

- **按应用降分辨率（Android 12 及以上）**：改用系统 Game Mode 的 downscale 介入，只缩小目标应用自己的渲染缓冲，不动整块屏幕，也不需要常驻服务，见"使用方法"里的模式说明。

## 一、云端编译 APK（三步）

1. **建仓库、传源码**：在 GitHub 新建一个仓库（Public/Private 均可）→ Add file → Upload files，把 `帧率助手-项目源码.zip` 解压后的**全部内容**（app 文件夹和几个 gradle 配置文件）直接拖进上传区，提交。
   - 本 zip 已去掉外层目录和隐藏的 `.github` 目录，解压即拖，不会丢结构；`.gitignore` 若被网页上传忽略也没关系，不影响编译。
2. **单独添加编译配置**：仓库页 → Add file → Create new file，文件名填 `.github/workflows/build.yml`（斜杠会自动变成目录），把单独发给你的 `build.yml` 文件内容完整粘贴进去，提交。提交后 Actions 立即自动开始编译（约 3–6 分钟），进入仓库的 **Actions** 标签页，看到绿色 ✓ 即编译成功（工作流会先跑单元测试再打包）。
3. **下载安装**：点进那次运行记录，页面底部 **Artifacts** 里下载 `ResoBoost-debug-APK`，解压得到 `app-debug.apk`，传到手机安装（debug 签名可直接安装）。

> 之后每次改动 push 都会自动重新编译；也可以在 Actions 页手动点 "Run workflow" 触发。

## 二、手机端准备

1. 安装 [Shizuku](https://shizuku.rikka.app/)（酷安 / GitHub / Play 商店均可）。
2. 激活 Shizuku：
   - Android 11+：Shizuku 内选"无线调试"，按提示配对启动（手机重启后需重新激活）；
   - 旧版本：用电脑执行 `adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh`。
3. 打开帧率助手 → 点 **授权 Shizuku** → 在弹窗中允许。

## 三、使用方法

1. 在应用列表勾选要加速的游戏/应用；
2. 点每行的百分比可改目标分辨率（默认 75%，越低帧率提升越明显、画面越糊，也可自定义宽高）；
3. 选择一种生效方式（界面上的 **按应用降分辨率** 开关）：

### 模式一：全局切换（默认，兼容所有版本）

- 打开 **开启自动切换** 开关启动常驻服务；
- 目标应用一到前台，把整块屏幕临时降分辨率，切出、熄屏立即恢复；通知栏常驻显示状态，可随时点"停止"。

### 模式二：按应用降分辨率（Android 12 及以上）

- 走系统 Game Mode 的 downscale 介入，只降低目标应用自己的渲染分辨率，**不动整块屏幕**；
- 不闪屏、切走不需要恢复、也不会留下跨重启的分辨率残留，**不需要常驻服务**；
- 勾选即写入系统，改档位会立刻重新下发；换机/换系统后可点 **同步全部规则到系统** 重新下发一遍；
- 目标应用需要重启一次才生效（正在运行的游戏先杀掉再进）。

系统接口按版本自动选择：

| 系统版本 | 写入 | 复位 |
| --- | --- | --- |
| Android 12 | `cmd game downscale <比例> <包名>` | `cmd game downscale disable <包名>` |
| Android 13 | `device_config put game_overlay <包名> mode=2,downscaleFactor=<比例>` + `cmd game mode 2 <包名>` | `cmd game mode 1` + `cmd game reset` + `device_config delete game_overlay` |
| Android 14+ | `cmd game set --mode 2 --downscale <比例> <包名>` | `cmd game reset` + `cmd game mode standard` |

限制：Android 13 起系统只对声明了 `android:appCategory="game"` 的应用生效（正常游戏都会声明），普通应用会提示设置失败；Android 12 对任何应用都可以。部分厂商 ROM 可能裁剪了 `cmd game`，失败时应用会给出返回信息。

建议把本应用和 Shizuku 的电池优化设为"无限制"，减少后台被杀（模式二不依赖常驻服务）。

## 已知限制（系统机制决定，无法避免）

- 全局模式：切换分辨率瞬间屏幕会闪一下，部分应用会重建界面；
- 全局模式：降分辨率期间整个系统都是低分辨率（只是目标应用在前台时才生效，切走立即恢复）；
- 服务被系统强杀时可能来不及恢复分辨率——打开本 App 即自动恢复；
- 帧率提升幅度取决于游戏是否 GPU 瓶颈；CPU 瓶颈或锁帧的游戏提升有限；
- 部分游戏会检测分辨率变化并重启渲染，属正常现象；
- 按应用模式：系统的 downscale 只缩小渲染缓冲，游戏 UI/触控坐标不变；个别游戏会忽略该介入。

## 技术栈

Kotlin · minSdk 26 / targetSdk 34 · Shizuku API 13.1.5 · ViewBinding · GitHub Actions（JDK 17 + Gradle 8.7 + AGP 8.5.2）

---

内容由 AI 生成
