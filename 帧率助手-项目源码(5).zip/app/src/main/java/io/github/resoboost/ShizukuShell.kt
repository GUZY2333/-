package io.github.resoboost

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import moe.shizuku.server.IShizukuService
import rikka.shizuku.Shizuku

/**
 * 通过 Shizuku 以 shell 权限执行命令。
 *
 * 主通道：直接调用 Shizuku 服务端公开的 AIDL 接口 IShizukuService.newProcess，
 * 由服务端直接 fork shell 进程执行命令（无需 UserService，链路最短、最稳）。
 * 备用通道：UserService（个别新版服务端若移除 newProcess 时自动降级）。
 *
 * lastError 记录最近一次失败原因，供界面展示诊断。
 */
object ShizukuShell {

    private const val APP_ID = "io.github.resoboost"
    private const val BIND_TIMEOUT_MS = 8000L

    @Volatile
    private var directVerified = false

    @Volatile
    private var probing = false

    @Volatile
    private var service: IShellService? = null

    @Volatile
    private var bindRequested = false

    @Volatile
    private var bindStartedAt = 0L

    @Volatile
    var lastError: String? = null
        private set

    private val args = Shizuku.UserServiceArgs(
        ComponentName(APP_ID, ShellUserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("shell")
        .debuggable(false)
        .version(3)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IShellService.Stub.asInterface(binder)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            bindRequested = false
        }
    }

    fun isReady(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        false
    }

    fun isConnected(): Boolean = directVerified || service != null

    /** 触发连接探测/绑定，可由界面定时调用（内部异步，不阻塞主线程） */
    fun warmup() {
        if (isConnected() || probing || !isReady()) return
        probing = true
        Thread {
            try {
                exec("true")
            } finally {
                probing = false
            }
        }.start()
    }

    /** 主通道：服务端直接 fork 进程 */
    private fun execDirect(cmd: String): String? {
        return try {
            val binder = Shizuku.getBinder() ?: return null
            val svc = IShizukuService.Stub.asInterface(binder)
            val proc = svc.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val out = ParcelFileDescriptor.AutoCloseInputStream(proc.inputStream)
                .bufferedReader().use { it.readText() }
            proc.waitFor()
            proc.destroy()
            directVerified = true
            lastError = null
            out
        } catch (e: Exception) {
            lastError = "直连通道失败：${e.message ?: e.javaClass.simpleName}"
            null
        }
    }

    private fun ensureBound() {
        if (service != null || !isReady()) return
        val now = System.currentTimeMillis()
        if (bindRequested && now - bindStartedAt < BIND_TIMEOUT_MS) return
        if (bindRequested) {
            try {
                Shizuku.unbindUserService(args, connection, false)
            } catch (e: Exception) {
                // ignore
            }
            bindRequested = false
        }
        try {
            Shizuku.bindUserService(args, connection)
            bindRequested = true
            bindStartedAt = now
        } catch (e: Exception) {
            lastError = "UserService 绑定失败：${e.message ?: e.javaClass.simpleName}"
            bindRequested = false
        }
    }

    fun exec(cmd: String): String? {
        if (!isReady()) {
            lastError = "Shizuku 未运行或未授权"
            return null
        }
        // 主通道
        val direct = execDirect(cmd)
        if (direct != null) return direct
        // 备用通道：UserService
        ensureBound()
        val s = service ?: return null
        return try {
            val r = s.exec(cmd)
            if (r != null) lastError = null
            r
        } catch (e: Exception) {
            lastError = "命令服务调用失败：${e.message}"
            service = null
            bindRequested = false
            null
        }
    }
}
