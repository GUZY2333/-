package io.github.resoboost

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * 通过 Shizuku 以 shell 权限执行命令的轻量封装。
 * 所有方法都可能返回 null（Shizuku 未连接 / 未授权 / 执行失败），调用方需判空。
 */
object ShizukuShell {

    fun isReady(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        false
    }

    fun exec(cmd: String): String? {
        if (!isReady()) return null
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val out = process.inputStream.bufferedReader().use { it.readText() }
            process.waitFor()
            process.destroy()
            out
        } catch (e: Exception) {
            null
        }
    }
}
