package io.github.resoboost

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import io.github.resoboost.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AppListAdapter

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { _, _ ->
            runOnUiThread { refreshStatus() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = AppListAdapter(RuleStore(this))
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter
        binding.search.addTextChangedListener { adapter.filter(it?.toString().orEmpty()) }

        Shizuku.addRequestPermissionResultListener(permissionListener)

        binding.btnAuth.setOnClickListener {
            try {
                Shizuku.requestPermission(1001)
            } catch (e: Exception) {
                toast("Shizuku 未在运行，请先打开 Shizuku 并激活")
            }
        }

        binding.btnReset.setOnClickListener {
            if (!ShizukuShell.isReady()) {
                toast("请先启动 Shizuku 并授权")
                return@setOnClickListener
            }
            Thread {
                ShizukuShell.exec("wm size reset")
                runOnUiThread { toast("已恢复默认分辨率") }
            }.start()
        }

        setSwitchChecked(false)

        loadApps()

        // 第二道兜底：App 打开且服务未运行时，恢复默认分辨率，
        // 防止服务被杀后手机停留在低分辨率。
        Thread {
            if (!MonitorService.running && ShizukuShell.isReady()) {
                ShizukuShell.exec("wm size reset")
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        setSwitchChecked(MonitorService.running)
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun setSwitchChecked(checked: Boolean) {
        binding.switchMonitor.setOnCheckedChangeListener(null)
        binding.switchMonitor.isChecked = checked
        binding.switchMonitor.setOnCheckedChangeListener { _, c ->
            if (c) {
                if (!ShizukuShell.isReady()) {
                    toast("请先启动 Shizuku 并授权")
                    setSwitchChecked(false)
                    return@setOnCheckedChangeListener
                }
                requestNotificationPermissionIfNeeded()
                ContextCompat.startForegroundService(
                    this, Intent(this, MonitorService::class.java)
                )
                toast("自动切换已开启")
            } else {
                stopService(Intent(this, MonitorService::class.java))
                toast("自动切换已关闭，分辨率将恢复")
            }
        }
    }

    private fun refreshStatus() {
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }
        when {
            !binderAlive -> {
                binding.shizukuStatus.text =
                    "Shizuku 未运行：请先安装 Shizuku，并通过无线调试或电脑激活"
                binding.btnAuth.isEnabled = false
            }
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> {
                binding.shizukuStatus.text = "Shizuku 运行中，尚未授权本应用"
                binding.btnAuth.isEnabled = true
            }
            else -> {
                binding.shizukuStatus.text = "Shizuku 已就绪 ✓"
                binding.btnAuth.isEnabled = false
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1002)
        }
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val items = pm.getInstalledApplications(0)
                .filter {
                    it.packageName != packageName &&
                        pm.getLaunchIntentForPackage(it.packageName) != null
                }
                .map { AppItem(it.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .sortedBy { it.label }
            runOnUiThread { adapter.submit(items) }
        }.start()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
